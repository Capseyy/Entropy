#include "tag.h"
#include "TigerEngine/package.h"
#include "TigerEngine/globaldata.h"
#include "TigerEngine/helpers.h"


int TagHash::getPkgId() {
	uint16_t pkgID = floor((hash - 0x80800000) / 8192);
	return pkgID;
}

int TagHash::getEntryID() {
	uint32_t entryId = hash & 0x1FFF;
	return entryId;
}

std::string TagHash::GetPackageName()
{
	auto& map = GlobalData::getMap();
	int pkgId = getPkgId();
	auto it = map.find(pkgId);
	if (it == map.end()) {
		printf("Invalid package ID: %d found for taghash %d\n ", pkgId, hash);
		size = 0;
		data = nullptr;
		return nullptr;
	}
	Package* pkg = &it->second;
	return pkg->PackageName;
}

unsigned char* TagHash::getData() {
	if (hash == 0 or hash == 4294967295) {
		size = 0;
		data = nullptr;
		return nullptr;
	}
	int pkgId = getPkgId();
	int entryId = getEntryID();
	auto& map = GlobalData::getMap();
	auto it = map.find(pkgId);
	if (it == map.end()) {
		printf("Invalid package ID: %d found for taghash %d\n ", pkgId, hash);
		size = 0;
		data = nullptr;
		return nullptr;
	}
	Package* pkg = &it->second;
	//printf("Extracting tag %08X\n", hash);
	const auto ReturnObject = pkg->ExtractEntry(entryId);
	success = ReturnObject.success;
	size = pkg->Entries[entryId].file_size;
	reference = pkg->Entries[entryId].reference;
	data = ReturnObject.data;
	type = pkg->Entries[entryId].file_type;
	sub_type = pkg->Entries[entryId].file_subtype;
	return data;

}

unsigned char* TagHash::getDatawithPkg(Package* pkg) {
	if (hash == 0u || hash == 0xFFFFFFFFu) { size = 0; data = nullptr; return nullptr; }
	const int entryId = getEntryID();
	auto ret = pkg->ExtractEntry(entryId);
	success = ret.success;
	size = pkg->Entries[entryId].file_size;
	reference = pkg->Entries[entryId].reference;
	data = ret.data;        // NOTE: this buffer must be owned/freed somewhere!
	return data;
}

// const overload (just forwards via const_cast)
unsigned char* TagHash::getDatawithPkg(const Package* pkg) {
	return getDatawithPkg(const_cast<Package*>(pkg));
}

void TagHash::print_buffer() {
	for (size_t i = 0; i < size; ++i) {
		printf("%02X", data[i]); // print each byte as two-digit hex
	}
	printf("\n");
}

void WideHash::print() {
	std::ostream& os = std::cout;
	os << "WideHash {\n"
		<< "  Unk0: " << wideHashData.Unk0 << "\n"
		<< "  Unk4: " << wideHashData.Unk4 << "\n"
		<< "  Hash64: 0x" << std::hex << std::setw(16) << std::setfill('0')
		<< wideHashData.Hash64 << std::dec << "\n"
		<< "  size: " << size << "\n"
		<< "  reference: " << reference << "\n"
		<< "  success: " << std::boolalpha << success << "\n";

	if (data && size > 0) {
		os << "  data: ";
		for (std::size_t i = 0; i < size; ++i) {
			os << std::hex << std::setw(2) << std::setfill('0')
				<< static_cast<unsigned>(data[i]) << " ";
		}
		os << std::dec << "\n";
	}
	else {
		os << "  data: null\n";
	}
	os << "}\n";
}
unsigned char* WideHash::getData() {
	const auto& h64 = GlobalData::getH64();
	auto it = h64.find(wideHashData.Hash64);
	if (wideHashData.Unk0 != 0xffffffff) {
		TagHash toTagHash = TagHash(wideHashData.Unk0);
		size = toTagHash.size;
		reference = toTagHash.reference;
		success = toTagHash.success;
		data = toTagHash.data;
		tagHash32 = toTagHash.hash;
		return toTagHash.data;
	}
	
	if (it == h64.end()) {
		printf("H64 lookup failed for % \n", wideHashData.Hash64);
		return nullptr;
	}
	TagHash toTagHash = it->second;
	toTagHash.getData();
	//printf("Resolving WideHash 0x%016" PRIx64 " to TagHash %08X\n", wideHashData.Hash64, toTagHash.hash);
	size = toTagHash.size;
	reference = toTagHash.reference;
	success = toTagHash.success;
	data = toTagHash.data;
	tagHash32 = toTagHash.hash;
	return toTagHash.data;

}

void TagHash::free()
{
	if (data != nullptr) {
		// If getData() used malloc/realloc:
		std::free(data);
		// If getData() used new[] instead, use: delete[] data;

		data = nullptr;
		size = 0;
		success = false;
		reference = 0;
	}
}

