#pragma once
#include <cstddef>
#include <DirectXMath.h>
#include "d3d11.h"
#include <vector>
#include "TigerEngine/Map/static.h"
#include "wrl/client.h"
#include <glm/glm.hpp>
#include <glm/gtc/quaternion.hpp>
#include <glm/gtc/matrix_transform.hpp>  
#include "Renderer/Tools/ErrorLogger.h"

using namespace DirectX;

 inline Microsoft::WRL::ComPtr<ID3D11Buffer> g_cb1;
 inline Microsoft::WRL::ComPtr<ID3D11Buffer> g_cb1_fallback;

static inline float asfloat_u32(std::uint32_t u) {
	return std::bit_cast<float>(u);
}

void UpdateCB1(
	ID3D11DeviceContext* ctx,
	const DirectX::XMFLOAT3& meshOffset, float meshScale,
	float uvScaleX, float uvOffX, float uvOffY, std::uint32_t maxColorOrClampBits,
	const std::vector<SStaticInstanceTransform>& worlds
);


struct alignas(16) CB1Payload_override
{
	DirectX::XMFLOAT4X4 mesh_to_world;          
	DirectX::XMFLOAT4   position_scale;         
	DirectX::XMFLOAT4   position_offset;        
	DirectX::XMFLOAT4   texcoord0_scale_offset; 
	DirectX::XMFLOAT4   dynamic_sh_ao_values;   
};


struct CB1Payload {
	
	DirectX::XMFLOAT4 meshOffset_meshScale;   
	
	DirectX::XMFLOAT4 uvScale_uvOffset;       
	
    std::vector<DirectX::XMFLOAT4> instances[4];
};



CB1Payload_override UpdateCB1_Single(
    glm::vec4 model_offset,
    glm::vec4             model_scale,
    float            instance_scale,
    float             texScale,
    float             texOffX, float texOffY,
    const glm::quat& rot,      
    const glm::vec3& pos);

inline DirectX::XMMATRIX MakeWorld(const ObjectVectors& s) {
    using namespace DirectX;
    const XMMATRIX S = XMMatrixScaling(s.scale, s.scale, s.scale);

    
    const XMVECTOR q = XMVectorSet(s.rotation.w, s.rotation.x, s.rotation.y, s.rotation.z);
    const XMMATRIX R = XMMatrixRotationQuaternion(q);

    const XMMATRIX T = XMMatrixTranslation(s.translation.x, s.translation.y, s.translation.z);

    
    return S * R * T;
}

inline float from_bytes(uint8_t b0, uint8_t b1, uint8_t b2, uint8_t b3)
{
    uint32_t u = (uint32_t)b0 | ((uint32_t)b1 << 8) | ((uint32_t)b2 << 16) | ((uint32_t)b3 << 24);
    float f;
    std::memcpy(&f, &u, sizeof(f));
    return f;
}

static void CreateCB1_FreshDynamic(
    ID3D11Device* device,
    ID3D11DeviceContext* ctx,
    const DirectX::XMFLOAT3& meshOffset, float meshScale,
    float uvScaleX, float uvOffX, float uvOffY, std::uint32_t maxColorOrClampBits,
    const std::vector<ObjectVectors>& worlds, Microsoft::WRL::ComPtr<ID3D11Buffer>& b)
{
    using namespace DirectX;

    
    const size_t instCap = (65536u - 32u) / 64u;
    const size_t instCount = std::min(worlds.size(), instCap);

    
    const size_t rowCount = 2 + instCount * 4;
    std::vector<XMFLOAT4> rows(rowCount);   

    
    rows[0] = XMFLOAT4(meshOffset.x, meshOffset.y, meshOffset.z, meshScale);
    rows[1] = XMFLOAT4(uvScaleX, uvOffX, uvOffY, asfloat_u32(maxColorOrClampBits));

    
    XMFLOAT4 xm4;
    xm4.w = 1.0f;
    xm4.x = 1.0f;
    xm4.y = 1.0f;
    xm4.z = 9.40395e-38;


    for (size_t i = 0; i < instCount; ++i)
    {
        const size_t base = 2 + i * 4;

        XMMATRIX M = MakeWorld(worlds[i]);
        XMMATRIX Mt = XMMatrixTranspose(M); 

        float kMagic = from_bytes(0xF7, 0xFF, 0xFF, 0x01);
        Mt.r[3] = DirectX::XMVectorSet(1.0f, 1.0f, 1.0f, kMagic);
        XMStoreFloat4(&rows[base + 0], Mt.r[0]);
        XMStoreFloat4(&rows[base + 1], Mt.r[1]);
        XMStoreFloat4(&rows[base + 2], Mt.r[2]);
        XMStoreFloat4(&rows[base + 3], Mt.r[3]);
    }

    const UINT byteSize = static_cast<UINT>(rows.size() * sizeof(XMFLOAT4)); 

    D3D11_BUFFER_DESC bd{};
    bd.BindFlags = D3D11_BIND_CONSTANT_BUFFER;
    bd.ByteWidth = byteSize;
    bd.Usage = D3D11_USAGE_IMMUTABLE; 
    bd.CPUAccessFlags = 0;

    D3D11_SUBRESOURCE_DATA init{};
    init.pSysMem = rows.data();

    b.Reset();
    HRESULT hr = device->CreateBuffer(&bd, &init, b.GetAddressOf());
}


