#pragma once

class KeyboardEvent
{
public:
	enum EventType
	{
		Press,
		Pressed,
		Invalid,
		Release
	};

	KeyboardEvent();
	KeyboardEvent(const EventType keyCode, const unsigned char key);
	bool IsPress() const;
	bool IsRelease() const;
	bool IsValid() const;
	unsigned char GetKeyCode() const;

private:
	EventType type;
	unsigned char key;
};

